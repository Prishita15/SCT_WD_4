import { useState } from "react";
import { TaskList } from "../types";
import { cn } from "../utils/cn";

interface TaskFormProps {
  onSubmit: (title: string, dueDate: string | null, dueTime: string | null, listId: string) => void;
  lists: TaskList[];
  defaultListId: string;
}

export function TaskForm({ onSubmit, lists, defaultListId }: TaskFormProps) {
  const [title, setTitle] = useState("");
  const [dueDate, setDueDate] = useState("");
  const [dueTime, setDueTime] = useState("");
  const [listId, setListId] = useState(defaultListId);
  const [showOptions, setShowOptions] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;
    onSubmit(title.trim(), dueDate || null, dueTime || null, listId);
    setTitle("");
    setDueDate("");
    setDueTime("");
    setShowOptions(false);
  };

  return (
    <form onSubmit={handleSubmit} className="bg-slate-800/50 backdrop-blur rounded-xl border border-slate-700 overflow-hidden">
      <div className="flex items-center gap-3 p-4">
        <div className="w-5 h-5 rounded-full border-2 border-slate-500 flex-shrink-0" />
        <input
          type="text"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="Add a new task..."
          className="flex-1 bg-transparent text-white placeholder-slate-400 focus:outline-none"
        />
        <button
          type="button"
          onClick={() => setShowOptions(!showOptions)}
          className={cn(
            "p-2 rounded-lg transition-colors",
            showOptions ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white hover:bg-slate-700"
          )}
        >
          <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
          </svg>
        </button>
      </div>

      {showOptions && (
        <div className="px-4 pb-4 pt-2 border-t border-slate-700 space-y-3">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block text-xs text-slate-400 mb-1">Due Date</label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                className="w-full bg-slate-700/50 text-white px-3 py-2 rounded-lg border border-slate-600 focus:border-indigo-500 focus:outline-none text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1">Time</label>
              <input
                type="time"
                value={dueTime}
                onChange={(e) => setDueTime(e.target.value)}
                className="w-full bg-slate-700/50 text-white px-3 py-2 rounded-lg border border-slate-600 focus:border-indigo-500 focus:outline-none text-sm"
              />
            </div>
            <div>
              <label className="block text-xs text-slate-400 mb-1">List</label>
              <select
                value={listId}
                onChange={(e) => setListId(e.target.value)}
                className="w-full bg-slate-700/50 text-white px-3 py-2 rounded-lg border border-slate-600 focus:border-indigo-500 focus:outline-none text-sm"
              >
                {lists.map((list) => (
                  <option key={list.id} value={list.id}>
                    {list.name}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={!title.trim()}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-lg transition-colors text-sm font-medium"
            >
              Add Task
            </button>
          </div>
        </div>
      )}
    </form>
  );
}
