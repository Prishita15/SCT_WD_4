import { useState } from "react";
import { Task, TaskList } from "../types";
import { cn } from "../utils/cn";

interface TaskItemProps {
  task: Task;
  lists: TaskList[];
  isEditing: boolean;
  onToggleComplete: () => void;
  onEdit: () => void;
  onCancelEdit: () => void;
  onSaveEdit: (updates: Partial<Task>) => void;
  onDelete: () => void;
}

export function TaskItem({
  task,
  lists,
  isEditing,
  onToggleComplete,
  onEdit,
  onCancelEdit,
  onSaveEdit,
  onDelete,
}: TaskItemProps) {
  const [editTitle, setEditTitle] = useState(task.title);
  const [editDate, setEditDate] = useState(task.dueDate || "");
  const [editTime, setEditTime] = useState(task.dueTime || "");
  const [editListId, setEditListId] = useState(task.listId);

  const list = lists.find((l) => l.id === task.listId);

  const handleSave = () => {
    if (!editTitle.trim()) return;
    onSaveEdit({
      title: editTitle,
      dueDate: editDate || null,
      dueTime: editTime || null,
      listId: editListId,
    });
  };

  const formatDateTime = () => {
    if (!task.dueDate) return null;
    const date = new Date(task.dueDate);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const tomorrow = new Date(today);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const taskDate = new Date(task.dueDate);
    taskDate.setHours(0, 0, 0, 0);

    let dateStr = "";
    if (taskDate.getTime() === today.getTime()) {
      dateStr = "Today";
    } else if (taskDate.getTime() === tomorrow.getTime()) {
      dateStr = "Tomorrow";
    } else {
      dateStr = date.toLocaleDateString("en-US", {
        month: "short",
        day: "numeric",
      });
    }

    if (task.dueTime) {
      const [hours, minutes] = task.dueTime.split(":");
      const time = new Date();
      time.setHours(parseInt(hours), parseInt(minutes));
      dateStr += ` at ${time.toLocaleTimeString("en-US", {
        hour: "numeric",
        minute: "2-digit",
      })}`;
    }

    return dateStr;
  };

  const isOverdue = () => {
    if (!task.dueDate || task.completed) return false;
    const now = new Date();
    const dueDate = new Date(task.dueDate);
    if (task.dueTime) {
      const [hours, minutes] = task.dueTime.split(":");
      dueDate.setHours(parseInt(hours), parseInt(minutes));
    } else {
      dueDate.setHours(23, 59, 59);
    }
    return now > dueDate;
  };

  if (isEditing) {
    return (
      <div className="bg-slate-700/50 backdrop-blur rounded-xl p-4 border border-slate-600">
        <input
          type="text"
          value={editTitle}
          onChange={(e) => setEditTitle(e.target.value)}
          className="w-full bg-slate-600/50 text-white px-3 py-2 rounded-lg border border-slate-500 focus:border-indigo-500 focus:outline-none mb-3"
          autoFocus
        />
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
          <input
            type="date"
            value={editDate}
            onChange={(e) => setEditDate(e.target.value)}
            className="bg-slate-600/50 text-white px-3 py-2 rounded-lg border border-slate-500 focus:border-indigo-500 focus:outline-none"
          />
          <input
            type="time"
            value={editTime}
            onChange={(e) => setEditTime(e.target.value)}
            className="bg-slate-600/50 text-white px-3 py-2 rounded-lg border border-slate-500 focus:border-indigo-500 focus:outline-none"
          />
          <select
            value={editListId}
            onChange={(e) => setEditListId(e.target.value)}
            className="bg-slate-600/50 text-white px-3 py-2 rounded-lg border border-slate-500 focus:border-indigo-500 focus:outline-none"
          >
            {lists
              .filter((l) => l.id !== "all")
              .map((l) => (
                <option key={l.id} value={l.id}>
                  {l.name}
                </option>
              ))}
          </select>
        </div>
        <div className="flex gap-2 justify-end">
          <button
            onClick={onCancelEdit}
            className="px-4 py-2 text-slate-300 hover:bg-slate-600 rounded-lg transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg transition-colors"
          >
            Save
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      className={cn(
        "group bg-slate-800/50 backdrop-blur rounded-xl p-4 border border-slate-700 hover:border-slate-600 transition-all",
        task.completed && "opacity-60"
      )}
    >
      <div className="flex items-start gap-3">
        <button
          onClick={onToggleComplete}
          className={cn(
            "mt-0.5 w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all flex-shrink-0",
            task.completed
              ? "bg-green-500 border-green-500"
              : "border-slate-500 hover:border-indigo-500"
          )}
        >
          {task.completed && (
            <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
            </svg>
          )}
        </button>

        <div className="flex-1 min-w-0">
          <p
            className={cn(
              "text-white font-medium",
              task.completed && "line-through text-slate-400"
            )}
          >
            {task.title}
          </p>
          <div className="flex flex-wrap items-center gap-2 mt-1">
            {list && (
              <span
                className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full"
                style={{ backgroundColor: `${list.color}20`, color: list.color }}
              >
                <span
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ backgroundColor: list.color }}
                />
                {list.name}
              </span>
            )}
            {formatDateTime() && (
              <span
                className={cn(
                  "text-xs flex items-center gap-1",
                  isOverdue() ? "text-red-400" : "text-slate-400"
                )}
              >
                <svg className="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                {formatDateTime()}
              </span>
            )}
          </div>
        </div>

        <div className="flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={onEdit}
            className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-700 rounded-lg transition-colors"
            title="Edit"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
            </svg>
          </button>
          <button
            onClick={onDelete}
            className="p-1.5 text-slate-400 hover:text-red-400 hover:bg-slate-700 rounded-lg transition-colors"
            title="Delete"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}
