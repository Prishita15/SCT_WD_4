import { useState } from "react";
import { TaskList } from "../types";
import { cn } from "../utils/cn";

interface ListSidebarProps {
  lists: TaskList[];
  activeListId: string;
  onSelectList: (id: string) => void;
  onAddList: (name: string, color: string) => void;
  onDeleteList: (id: string) => void;
  taskCounts: Record<string, number>;
}

const colors = [
  "#6366f1", // indigo
  "#10b981", // emerald
  "#f59e0b", // amber
  "#ec4899", // pink
  "#8b5cf6", // violet
  "#06b6d4", // cyan
  "#ef4444", // red
  "#84cc16", // lime
];

export function ListSidebar({
  lists,
  activeListId,
  onSelectList,
  onAddList,
  onDeleteList,
  taskCounts,
}: ListSidebarProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [newListName, setNewListName] = useState("");
  const [newListColor, setNewListColor] = useState(colors[0]);

  const handleAddList = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newListName.trim()) return;
    onAddList(newListName.trim(), newListColor);
    setNewListName("");
    setNewListColor(colors[0]);
    setShowAddForm(false);
  };

  return (
    <div className="h-full flex flex-col p-4">
      {/* Logo */}
      <div className="flex items-center gap-3 mb-8 px-2">
        <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center">
          <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
          </svg>
        </div>
        <div>
          <h1 className="text-xl font-bold text-white">TaskMaster</h1>
          <p className="text-xs text-slate-400">Stay organized</p>
        </div>
      </div>

      {/* Lists */}
      <div className="flex-1 space-y-1">
        <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-2 mb-2">
          Lists
        </p>
        {lists.map((list) => (
          <div
            key={list.id}
            className={cn(
              "group flex items-center justify-between rounded-lg transition-colors",
              activeListId === list.id
                ? "bg-slate-700/50"
                : "hover:bg-slate-700/30"
            )}
          >
            <button
              onClick={() => onSelectList(list.id)}
              className="flex-1 flex items-center gap-3 px-3 py-2.5 text-left"
            >
              <span
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: list.color }}
              />
              <span
                className={cn(
                  "font-medium",
                  activeListId === list.id ? "text-white" : "text-slate-300"
                )}
              >
                {list.name}
              </span>
            </button>
            <div className="flex items-center gap-1 pr-2">
              <span className="text-xs text-slate-500 min-w-[20px] text-center">
                {taskCounts[list.id] || 0}
              </span>
              {list.id !== "all" && (
                <button
                  onClick={() => onDeleteList(list.id)}
                  className="p-1 text-slate-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                  </svg>
                </button>
              )}
            </div>
          </div>
        ))}

        {/* Add List Button */}
        {!showAddForm && (
          <button
            onClick={() => setShowAddForm(true)}
            className="flex items-center gap-3 w-full px-3 py-2.5 text-slate-400 hover:text-white hover:bg-slate-700/30 rounded-lg transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
            </svg>
            <span className="font-medium">Add List</span>
          </button>
        )}

        {/* Add List Form */}
        {showAddForm && (
          <form onSubmit={handleAddList} className="p-3 bg-slate-700/30 rounded-lg space-y-3">
            <input
              type="text"
              value={newListName}
              onChange={(e) => setNewListName(e.target.value)}
              placeholder="List name"
              className="w-full bg-slate-600/50 text-white placeholder-slate-400 px-3 py-2 rounded-lg border border-slate-500 focus:border-indigo-500 focus:outline-none text-sm"
              autoFocus
            />
            <div className="flex flex-wrap gap-2">
              {colors.map((color) => (
                <button
                  key={color}
                  type="button"
                  onClick={() => setNewListColor(color)}
                  className={cn(
                    "w-6 h-6 rounded-full transition-transform",
                    newListColor === color && "ring-2 ring-white ring-offset-2 ring-offset-slate-800 scale-110"
                  )}
                  style={{ backgroundColor: color }}
                />
              ))}
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setShowAddForm(false)}
                className="flex-1 px-3 py-1.5 text-slate-300 hover:bg-slate-600 rounded-lg transition-colors text-sm"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!newListName.trim()}
                className="flex-1 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white rounded-lg transition-colors text-sm"
              >
                Add
              </button>
            </div>
          </form>
        )}
      </div>

      {/* Footer */}
      <div className="pt-4 border-t border-slate-700 mt-4">
        <div className="text-center">
          <p className="text-xs text-slate-500">
            {lists.reduce((acc, l) => acc + (taskCounts[l.id] || 0), 0) / lists.length | 0} tasks in total
          </p>
        </div>
      </div>
    </div>
  );
}
