import { useState, useEffect } from "react";
import { Task, TaskList } from "./types";
import { TaskItem } from "./components/TaskItem";
import { TaskForm } from "./components/TaskForm";
import { ListSidebar } from "./components/ListSidebar";
import { cn } from "./utils/cn";

const defaultLists: TaskList[] = [
  { id: "all", name: "All Tasks", color: "#6366f1" },
  { id: "personal", name: "Personal", color: "#10b981" },
  { id: "work", name: "Work", color: "#f59e0b" },
  { id: "shopping", name: "Shopping", color: "#ec4899" },
];

export function App() {
  const [tasks, setTasks] = useState<Task[]>(() => {
    const saved = localStorage.getItem("tasks");
    return saved ? JSON.parse(saved) : [];
  });

  const [lists, setLists] = useState<TaskList[]>(() => {
    const saved = localStorage.getItem("lists");
    return saved ? JSON.parse(saved) : defaultLists;
  });

  const [activeListId, setActiveListId] = useState("all");
  const [showCompleted, setShowCompleted] = useState(true);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => {
    localStorage.setItem("tasks", JSON.stringify(tasks));
  }, [tasks]);

  useEffect(() => {
    localStorage.setItem("lists", JSON.stringify(lists));
  }, [lists]);

  const addTask = (title: string, dueDate: string | null, dueTime: string | null, listId: string) => {
    const newTask: Task = {
      id: crypto.randomUUID(),
      title,
      completed: false,
      dueDate,
      dueTime,
      listId: listId || "personal",
      createdAt: new Date(),
    };
    setTasks([newTask, ...tasks]);
  };

  const updateTask = (id: string, updates: Partial<Task>) => {
    setTasks(tasks.map((task) => (task.id === id ? { ...task, ...updates } : task)));
    setEditingTask(null);
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter((task) => task.id !== id));
  };

  const toggleComplete = (id: string) => {
    setTasks(
      tasks.map((task) =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const addList = (name: string, color: string) => {
    const newList: TaskList = {
      id: crypto.randomUUID(),
      name,
      color,
    };
    setLists([...lists, newList]);
  };

  const deleteList = (id: string) => {
    if (id === "all") return;
    setLists(lists.filter((list) => list.id !== id));
    setTasks(tasks.filter((task) => task.listId !== id));
    if (activeListId === id) setActiveListId("all");
  };

  const filteredTasks = tasks.filter((task) => {
    const matchesList = activeListId === "all" || task.listId === activeListId;
    const matchesCompleted = showCompleted || !task.completed;
    return matchesList && matchesCompleted;
  });

  const incompleteTasks = filteredTasks.filter((t) => !t.completed);
  const completedTasks = filteredTasks.filter((t) => t.completed);

  const activeList = lists.find((l) => l.id === activeListId) || lists[0];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Mobile Header */}
      <div className="lg:hidden flex items-center justify-between p-4 border-b border-slate-700">
        <button
          onClick={() => setSidebarOpen(true)}
          className="p-2 text-slate-300 hover:bg-slate-700 rounded-lg"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <h1 className="text-xl font-bold text-white">TaskMaster</h1>
        <div className="w-10" />
      </div>

      <div className="flex">
        {/* Sidebar Overlay */}
        {sidebarOpen && (
          <div
            className="fixed inset-0 bg-black/50 z-40 lg:hidden"
            onClick={() => setSidebarOpen(false)}
          />
        )}

        {/* Sidebar */}
        <aside
          className={cn(
            "fixed lg:static inset-y-0 left-0 z-50 w-72 bg-slate-800/50 backdrop-blur-xl border-r border-slate-700 transform transition-transform duration-300 lg:transform-none",
            sidebarOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
          )}
        >
          <ListSidebar
            lists={lists}
            activeListId={activeListId}
            onSelectList={(id: string) => {
              setActiveListId(id);
              setSidebarOpen(false);
            }}
            onAddList={addList}
            onDeleteList={deleteList}
            taskCounts={lists.reduce((acc, list) => {
              acc[list.id] = tasks.filter(
                (t) => (list.id === "all" || t.listId === list.id) && !t.completed
              ).length;
              return acc;
            }, {} as Record<string, number>)}
          />
        </aside>

        {/* Main Content */}
        <main className="flex-1 min-h-screen p-4 lg:p-8">
          <div className="max-w-3xl mx-auto">
            {/* Header */}
            <div className="mb-8">
              <div className="flex items-center gap-3 mb-2">
                <div
                  className="w-4 h-4 rounded-full"
                  style={{ backgroundColor: activeList.color }}
                />
                <h1 className="text-3xl font-bold text-white">{activeList.name}</h1>
              </div>
              <p className="text-slate-400">
                {incompleteTasks.length} task{incompleteTasks.length !== 1 ? "s" : ""} remaining
              </p>
            </div>

            {/* Add Task Form */}
            <TaskForm
              onSubmit={addTask}
              lists={lists.filter((l) => l.id !== "all")}
              defaultListId={activeListId === "all" ? "personal" : activeListId}
            />

            {/* Tasks */}
            <div className="mt-6 space-y-3">
              {incompleteTasks.length === 0 && completedTasks.length === 0 && (
                <div className="text-center py-12">
                  <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-slate-700/50 mb-4">
                    <svg className="w-8 h-8 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                  </div>
                  <h3 className="text-lg font-medium text-slate-300 mb-1">No tasks yet</h3>
                  <p className="text-slate-500">Add a task above to get started</p>
                </div>
              )}

              {incompleteTasks.map((task) => (
                <TaskItem
                  key={task.id}
                  task={task}
                  lists={lists}
                  isEditing={editingTask?.id === task.id}
                  onToggleComplete={() => toggleComplete(task.id)}
                  onEdit={() => setEditingTask(task)}
                  onCancelEdit={() => setEditingTask(null)}
                  onSaveEdit={(updates) => updateTask(task.id, updates)}
                  onDelete={() => deleteTask(task.id)}
                />
              ))}

              {/* Completed Section */}
              {completedTasks.length > 0 && (
                <div className="pt-4">
                  <button
                    onClick={() => setShowCompleted(!showCompleted)}
                    className="flex items-center gap-2 text-slate-400 hover:text-slate-300 transition-colors mb-3"
                  >
                    <svg
                      className={cn("w-4 h-4 transition-transform", showCompleted && "rotate-90")}
                      fill="none"
                      stroke="currentColor"
                      viewBox="0 0 24 24"
                    >
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                    </svg>
                    Completed ({completedTasks.length})
                  </button>

                  {showCompleted && (
                    <div className="space-y-3">
                      {completedTasks.map((task) => (
                        <TaskItem
                          key={task.id}
                          task={task}
                          lists={lists}
                          isEditing={editingTask?.id === task.id}
                          onToggleComplete={() => toggleComplete(task.id)}
                          onEdit={() => setEditingTask(task)}
                          onCancelEdit={() => setEditingTask(null)}
                          onSaveEdit={(updates) => updateTask(task.id, updates)}
                          onDelete={() => deleteTask(task.id)}
                        />
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
